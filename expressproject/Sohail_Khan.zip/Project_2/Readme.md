https://stackabuse.com/guide-to-handlebars-templating-engine-for-node/

https://jasonwatmore.com/post/2019/07/18/react-node-server-side-pagination-tutorial-example 

- Drive Link for this project
For App.js file
- https://drive.google.com/file/d/1sqUKT5AAwhOzi_ltWCjWpE_4hlSzDfM9/view 



